# GRUT interacting-history replication packet

This archive contains both independent-history source/results and the original QED packet it imports. It is not a publication release. All matching/reduction misses are retained. Zenodo remains paused.

Start with `research/reality_framework/grut_detector_matching_20261107/README.md`. The manifest records the original source commit and physics freezes. Extraction does not recreate historical Git metadata. The documented local bootstrap creates a new commit solely to allow the clean-tree execution guards; source hashes retain the historical comparison.

From the extracted archive root, before installing or executing anything:

```sh
python - <<'PY'
import hashlib,json
from pathlib import Path
m=json.loads(Path('PACKET_MANIFEST.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in m['sha256'].items())
print('Manifest matches',len(m['sha256']),'files; source',m['archive_source_commit'])
PY
git init -q
git add .
git -c user.name='Local replica' -c user.email='replica@localhost' commit -q -m 'Import verified replication packet'
```

Then follow the repository instructions in the nested README. Put the environment and outputs outside the extracted tree. Only NumPy and SciPy are needed for the new reference. TeNPy is optional and used only for the original four-case DMRG replay. Installing these dependencies may require network access.
